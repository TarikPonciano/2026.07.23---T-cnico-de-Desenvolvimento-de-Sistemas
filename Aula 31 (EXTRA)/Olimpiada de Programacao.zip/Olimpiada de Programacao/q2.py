# =============================================
# Título: Banho de animais
#
# Contexto: Fernando precisava de um sistema que organizasse os preços de banho dos animais. 
# x
# Crie um programa que receba o nome do animal e informe o valor do serviço, declare uma lista com alguns animais.
# 
#
# Exemplo 1:
#  Valores do banho dos animais
# Digite o nome do animal: Gato
# Gato | R$ 35.0


# =============================================
print("\nValores do banho dos animais\n")
animais = [
    {"Nome": "Gato", "Preço": 35.00},
    {"Nome": "Cachorro", "Preço": 50.00},
    {"Nome": "Papagaio", "Preço": 20.00},
    {"Nome": "Coelho", "Preço": 45.00},
    {"Nome": "Tartaruga", "Preço": 100.00}
]

nome = input("Digite o nome do animal: ")
for animal in animais:
    if nome == animal["Nome"]:
        print(f"{animal["Nome"]} | R$ {animal["Preço"]}")