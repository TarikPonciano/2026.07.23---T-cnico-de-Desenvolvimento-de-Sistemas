# =============================================
# Título: Descontos e Gorjetas
#
# Contexto:
# Um restaurante precisa calcular um desconto de 10% em cima do valor de um cliente se caso seu consumo for acima de R$ 150.
# Se caso não tiver desconto informe também.
# Logo após calcule a gorjeta do garçom: se o valor do cliente for maior que R$ 200 o garçom recebe 10% desse valor, se for acima de R$ 300 o garçom recebe 15% do valor.
# Imprima a nota fiscal no final.

# Exemplo 1:
#  == Restaurante ==
# Digite o valor da conta do cliente: 500
#  -- Nota Fiscal --
#     Valor da compra: R$ 500.0
#     Desconto aprovado: Desconto de 10% aprovado

#     Valor Total a pagar: R$ 450.0

# -----------------------------------------

# -- Gorjeta do garçom --
# Ganhou comissão de 10% em cima do valor total do cliente.
# R$ 50.0

# Exemplo 2
# == Restaurante ==
# Digite o valor da conta do cliente: 50
#  -- Nota Fiscal --
#     Valor da compra: R$ 50.0
#     Desconto aprovado: Sem desconto aprovado

#     Valor Total a pagar: R$ 50.0

# -----------------------------------------

# -- Gorjeta do garçom --
# Sem comissão.
# R$ 0

# =============================================



print("== Restaurante ==")
valor = float(input("Digite o valor da conta do cliente: "))

if valor >= 150: 
    valor_desconto = valor * 0.9
    desconto = ("Desconto de 10% aprovado")
else:
    valor_desconto = valor
    desconto = ("Sem desconto aprovado")

if valor > 200:
    comissao = valor * 0.1
    op = ("Ganhou comissão de 10% em cima do valor total do cliente.")
elif valor >= 300:
    comissao = valor * 0.15
    op = ("Ganhou comissão de 15% em cima do valor total do cliente.")
else:
    comissao = 0
    op = ("Sem comissão.")
    
print(f""" -- Nota Fiscal --
    Valor da compra: R$ {valor}
    Desconto aprovado: {desconto}

    Valor Total a pagar: R$ {valor_desconto}

-----------------------------------------

-- Gorjeta do garçom --
{op}
R$ {comissao}
""")