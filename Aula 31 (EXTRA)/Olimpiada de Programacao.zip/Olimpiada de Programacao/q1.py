# Equipe: 
# Integrantes: Ryan, Jorge, Thais, Pedro


# =============================================
# Título: Estoque de uma Farmácia

# Contexto:
# Lucas precisa organizar o estoque de sua nova farmácia e precisa de um programa que ajude ele com esse processo.

# Crie um programa de gerenciamento de estoque com as seguintes funções:
# 1. Cadastrar novo medicamento.
# 2. Vizualizar medicamentos em estoque.
# 0. Sair do sistema.
# 
# Utilize o dicionário a seguir para facilitar no texte do programa.
# medicamentos = [ 
#     {"Nome": "Amoxicilina", "Preço": 45.90, "Quantidade em estoque": 120},
#     {"Nome": "Ibuprofeno", "Preço": 18.50, "Quantidade em estoque": 85},
#     {"Nome": "Paracetamol", "Preço": 12.30, "Quantidade em estoque": 200},
#     {"Nome": "Dipirona Monoidratada", "Preço": 15.20, "Quantidade em estoque": 150},
#     {"Nome": "Omeprazol", "Preço": 28.90, "Quantidade em estoque": 90},
#     {"Nome": "Losartana Potássica", "Preço": 22.40, "Quantidade em estoque": 110},
#     {"Nome": "Simvastatina", "Preço": 35.60, "Quantidade em estoque": 65},
#     {"Nome": "Cloridrato de Metformina", "Preço": 19.80, "Quantidade em estoque": 140},
#     {"Nome": "Cetoconazol Creme", "Preço": 24.15, "Quantidade em estoque": 40},
#     {"Nome": "Azitromicina", "Preço": 33.00, "Quantidade em estoque": 75}
# ]

# Exemplo 1:
# === ESTOQUE DA FARMÁCIA ===
#     1. Cadastrar novo medicamento no estoque.
#     2. Vizualizar medicamentos em estoque.
          
#     0. Sair do sistema.
    
# --> 1

# == Cadastro de Medicamentos ==

# Digite o nome do remédio: 
# Digite o preço do remédio: 
# Digite quantos entrará no estoque: 

# Medicamento cadastrado com sucesso!

# === ESTOQUE DA FARMÁCIA ===
#     1. Cadastrar novo medicamento no estoque.
#     2. Vizualizar medicamentos em estoque.
          
#     0. Sair do sistema.
    
# --> 2

# == Vizualisar Medicamentos em Estoque ==

# (Listar os medicamentos.)

# =============================================
medicamentos = [ 
    {"Nome": "Amoxicilina", "Preço": 45.90, "Quantidade em estoque": 120},
    {"Nome": "Ibuprofeno", "Preço": 18.50, "Quantidade em estoque": 85},
    {"Nome": "Paracetamol", "Preço": 12.30, "Quantidade em estoque": 200},
    {"Nome": "Dipirona Monoidratada", "Preço": 15.20, "Quantidade em estoque": 150},
    {"Nome": "Omeprazol", "Preço": 28.90, "Quantidade em estoque": 90},
    {"Nome": "Losartana Potássica", "Preço": 22.40, "Quantidade em estoque": 110},
    {"Nome": "Simvastatina", "Preço": 35.60, "Quantidade em estoque": 65},
    {"Nome": "Cloridrato de Metformina", "Preço": 19.80, "Quantidade em estoque": 140},
    {"Nome": "Cetoconazol Creme", "Preço": 24.15, "Quantidade em estoque": 40},
    {"Nome": "Azitromicina", "Preço": 33.00, "Quantidade em estoque": 75}
]
while True:
    print("""
=== ESTOQUE DA FARMÁCIA ===
    1. Cadastrar novo medicamento no estoque.
    2. Vizualizar medicamentos em estoque.
          
    0. Sair do sistema.
    """)
    op = input("--> ")
    if op == "1":
        print()
        print("== Cadastro de Medicamentos ==")
        print()
        nome = input("Digite o nome do remédio: ")
        preco = float(input("Digite o preço do remédio: "))
        qtd_em_estoque = input("Digite quantos entrará no estoque: ")

        novo_medicamento = {
            "Nome": nome,
            "Preço": preco,
            "Quantidade em estoque": qtd_em_estoque
        }

        medicamentos.append(novo_medicamento)
        print()
        print("Medicamento cadastrado com sucesso!")

    elif op == "2":
        print()
        print("== Vizualisar Medicamentos em Estoque ==")
        print()
        for i, medicamento in enumerate(medicamentos):
            print(f"{i+1}. {medicamento["Nome"]} | Estoque: {medicamento["Quantidade em estoque"]}")
        print()
        input("Digite Enter para sair.")
        
    elif op == "0":
        break
    else:
        print("Opção escolhida inválida, digite novamente.")

input("Fim do programa.")