#q1# Equipe: Expressos Vermelhos de Monty
# Integrantes: Aline, Denzel, Lay e Stefano

#==========================================

# Título: Organizar os Rankings

# Contexto:
# Durante uma competição de natação, cada participante levou um determinado tempo para concluir a prova. Quanto menor o tempo, melhor será a colocação no ranking. Os participantes foram: Aline com 3 minutos, Denzel com 2 minutos, Lay com 5 minutos e Stefano com 4 minutos.

# Criar um programa que receba o nome dos participantes e o tempo que cada participante levou para concluir a prova. Organize as cronometragem em um ranking, do primeiro ao último lugar, considerando o menor tempo como a melhor colocação. Exiba o ranking final na tela.
nomes = []
tempos = []

for i in range(4):
    
    print(f"Participante {i+1}")
    
    nome = input("Digite o nome do participante: ")
    tempo = int(input("Digite o tempo da prova do participante em minutos: "))

    nomes.append(nome)
    tempos.append(tempo)   
    tempos.sort()
print(f"""
RANKING:
{tempos}
    """)

#q2
#Crie um programa (usando while) de cadastro de emprego para uma empresa de café,
#o programa precisa informar o nome, idade, salário, civil e sexo do funcionário. Além disso o nome precisa ter mais de 3 caracteres, a idade não pode passar de 150 anos, o sálario não pode ser menos que 0 e no final exiba

nome = ""
idade = 0
salario = 0
estado_civil = ""
sexo = ""





while True:
    nome = input("Digite o nome: ")
    if len(nome) > 3:
        break
    else:
        print("Erro digite um nome com mais de 3 caracteres ")
    print()
while True:
        idade = int(input("Digite sua idade: "))
        if 0 <= idade <= 150:
            break
        
        else:
            print("Erro Digite uma idade válida.")
while True:
        salario = float(input("Digite seu salário atual: "))
        if salario > 0:
            break
        else:
            print("Erro digite um salário maior que 0.")
while True:
        sexo = input("Digite sua idade (F/M/NB): ").lower()
        if sexo == "f" or sexo == "m" or sexo == "nb":
            break
        else:
            print("Erro digite F, M ou NB para continuar.")
while True:
        estado_civil = input("Digite o estado civil (s/c/v/d): ").lower()
        if estado_civil == "s" or estado_civil == "c" or estado_civil == "v" or estado_civil == "d":
            break
        else:
            print("Digite um estado civil válido.")

print(f"""
------------CADASTRO FEITO COM SUCESSO------------
nome:{nome}
idade:{idade}
sexo:{sexo}
salario:{salario}
estado civil:{estado_civil}

""")

# Equipe: Expressos Vermelhos de Monty
# Integrantes: Aline, Denzel, Lay e Stefano

#==========================================

# Título: Lista de Compras

# Contexto:
# Maria Chiquinha foi ao supermercado e decidiu anotar os produtos que precisava comprar. Ela quer ajuda para armazenar os nomes dos produtos em uma lista. 

# Criar um programa peça ao usuário o nome dos produtos e armazene-os em uma lista. Ao final, exiba todos os produtos cadastrados na tela e a quantidade de cada um.


lista = []

while True:

    nome = input("Digite o nome do produto (Ou digite 'sair' para finalizar): ")
    
    if nome == "sair":
        break

    quantidade = input("Digite a quantidade desejada desse produto: ")

    compras = {
        "Produto": nome,
        "Quantidade": quantidade
    }
    
    lista.append(compras)

print("\n------ LISTA DE COMPRAS ------")

for i in range(len(lista)):
    
    print(f"""
Produto: {lista[i]["Produto"]}
Quantidade: {lista[i]["Quantidade"]}
    """)